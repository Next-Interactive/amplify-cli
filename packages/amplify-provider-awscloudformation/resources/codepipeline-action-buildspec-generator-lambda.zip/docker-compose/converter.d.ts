import Container from './ecs-objects/Container';
declare type DockerServiceInfo = {
    buildspec: string;
    containers: Container[];
};
export declare function getContainers(composeContents?: string, dockerfileContents?: string): DockerServiceInfo;
export {};
//# sourceMappingURL=converter.d.ts.map