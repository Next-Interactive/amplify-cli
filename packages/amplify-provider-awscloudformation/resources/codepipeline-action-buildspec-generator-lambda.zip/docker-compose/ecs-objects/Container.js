"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Container {
    constructor(build, name, portMappings, command, entrypoint, env_file, environment, image, healthcheck, working_dir, user) {
        this.defaultLogConfiguration = {
            logDriver: 'awslogs',
            options: {
                'awslogs-group': '/ecs/fargate-task-definition',
                'awslogs-region': 'us-east-1',
                'awslogs-stream-prefix': 'ecs',
            },
        };
        this.logConfiguration = this.defaultLogConfiguration;
        this.build = build;
        this.name = name;
        this.portMappings = portMappings;
        this.command = command;
        this.entrypoint = entrypoint;
        this.env_file = env_file;
        this.environment = environment;
        this.image = image;
        this.healthcheck = healthcheck;
        this.working_dir = working_dir;
        this.user = user;
    }
}
exports.default = Container;
//# sourceMappingURL=Container.js.map