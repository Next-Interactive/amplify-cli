// @ts-check
const os = require("os");
const fs = require("fs");
const path = require("path");
const AWS = require("aws-sdk");
const extract = require('extract-zip');
const Archiver = require('archiver');
// @ts-ignore
const { getContainers } = require('./docker-compose');

/**
 * @typedef {{location: {s3Location: { bucketName: string, objectKey: string}}}} Artifact
 */

const codepipeline = new AWS.CodePipeline();

exports.handler = async (event) => {
    const {
        jobId,
        credentials,
        inputArtifact,
        outputArtifact,
        encryptionKeyId,
    } = parseEvent(event);

    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'foo-'));

    const s3 = new AWS.S3({ credentials });

    const sourceBuffer = await getFileFromS3(s3, inputArtifact);

    const inputArtifactsDir = await saveAndUnzip(sourceBuffer, tmpDir);

    saveBuildSpec(inputArtifactsDir);

    const outputArtifactZipPath = await createOutputArtifactZip(tmpDir, inputArtifactsDir);

    await sendFileToS3(s3, outputArtifact, outputArtifactZipPath, encryptionKeyId);

    return await codepipeline.putJobSuccessResult({ jobId }).promise();
};

function parseEvent(event) {
    const {
        ["CodePipeline.job"]: { id: jobId, data },
    } = event;
    const {
        artifactCredentials: credentials,
        inputArtifacts,
        outputArtifacts,
        encryptionKey: {
            id: encryptionKeyId
        } = { id: undefined },
    } = data;

    const [inputArtifact] = inputArtifacts;
    const [outputArtifact] = outputArtifacts;

    return {
        jobId,
        credentials,
        inputArtifact,
        outputArtifact,
        encryptionKeyId,
    };
}

/**
 * 
 * @param {AWS.S3} s3 
 * @param {Artifact} artifact
 * @returns {Promise<Buffer>}
 */
async function getFileFromS3(s3, artifact) {
    const {
        location: {
            s3Location: {
                bucketName: Bucket,
                objectKey: Key,
            }
        }
    } = artifact;

    /** @type {any} Body */
    const { Body } = await s3.getObject({ Bucket, Key }).promise();

    return Body;
}

/**
 * 
 * @param {Buffer} buffer 
 * @param {string} baseDir 
 */
async function saveAndUnzip(buffer, baseDir) {
    const zipFilePath = path.join(baseDir, 'inputArtifact.zip');

    fs.writeFileSync(zipFilePath, buffer);

    const dir = path.join(baseDir, 'unzippedArtifact');

    await extract(zipFilePath, { dir });

    fs.unlinkSync(zipFilePath);

    return dir;
}

/**
 * 
 * @param {string} dir 
 */
function saveBuildSpec(dir) {
    const [dockerfileContents, composeContents] = [
        'Dockerfile', 'docker-compose.yml'
    ].map(fileName => {
        const filePath = path.join(dir, fileName);

        if (!fs.existsSync(filePath)) {
            return;
        }

        return fs.readFileSync(filePath).toString();
    });

    const {
        buildspec,
    } = getContainers(composeContents, dockerfileContents);

    console.log({ buildspec });

    const buildspecPath = path.join(dir, 'buildspec.yml');
    fs.writeFileSync(buildspecPath, buildspec);
}

/**
 * 
 * @param {string} dest 
 * @param {string} src 
 */
async function createOutputArtifactZip(dest, src) {
    const archiver = Archiver.create('zip');

    const out = path.join(dest, 'Out.zip');

    const stream = fs.createWriteStream(out);

    archiver.pipe(stream);

    archiver.directory(src, false);

    await archiver.finalize();

    await new Promise(r => {
        stream.on('close', r);
    });

    return out;
}

/**
 * 
 * @param {AWS.S3} s3 S3 client
 * @param {Artifact} artifact 
 * @param {string} filePath 
 */
async function sendFileToS3(s3, artifact, filePath, encryptionKeyId) {
    const {
        location: {
            s3Location: {
                bucketName: Bucket,
                objectKey: Key,
            }
        }
    } = artifact;

    const Body = fs.readFileSync(filePath);
    const ContentType = 'application/zip';
    const SSEKMSKeyId = encryptionKeyId;

    await s3.putObject({ Bucket, Key, Body, ContentType, SSEKMSKeyId }).promise();
}
